"""Shared loader and helpers for the v2 experiment analysis.

Unit of replication = session (one fresh browser process). Within a session,
each (workload, N, cell) has 30 recorded runs; we summarise them by the median
and then make inferences across the 10 measured sessions per browser
(Georges et al. 2007; Kalibera & Jones 2013).
"""
from __future__ import annotations

import glob
import json
import os

import numpy as np
import pandas as pd
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUN = os.path.join(ROOT, "data", "run-20261020-070557")
OUT = os.path.join(ROOT, "out")
FIG = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

CELLS = ["A", "B-warm", "B-cold", "C", "D-warm", "D-cold"]
BROWSERS = ["chrome", "firefox"]
NS = [1000, 10000, 50000, 100000]


def load_runs(include_pilot: bool = False) -> pd.DataFrame:
    frames = []
    for f in sorted(glob.glob(os.path.join(RUN, "*", "*", "batch-*.csv"))):
        if f.endswith("-meta.json"):
            continue
        df = pd.read_csv(f, low_memory=False)
        frames.append(df)
    d = pd.concat(frames, ignore_index=True)
    if not include_pilot:
        d = d[d["sessionRole"] == "measure"].copy()
    d["browser"] = d["browserName"]
    # user-facing response time: dispatch -> result on main thread (core) or
    # -> output tables formatted (full); per-run workers add their start-up,
    # which happens before dispatch and is measured separately.
    start = d[["spawnMs", "initMs", "engineInitMs"]].fillna(0).sum(axis=1)
    cold = d["cell"].isin(["B-cold", "D-cold"])
    base = np.where(d["workload"] == "full", d["totalMs"], d["e2eMs"])
    d["startupMs"] = np.where(cold, start, 0.0)
    d["responseMs"] = base + d["startupMs"]
    return d


def load_native() -> pd.DataFrame:
    frames = [pd.read_csv(f) for f in sorted(glob.glob(os.path.join(RUN, "native", "invocation-*.csv")))]
    return pd.concat(frames, ignore_index=True)


def session_medians(d: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    keys = ["browser", "sessionId", "sessionIndex", "workload", "N", "cell"]
    return d.groupby(keys, as_index=False)[cols].median()


def t_ci(x, level=0.95):
    """Mean and t-based CI across sessions."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    m = x.mean()
    if n < 2:
        return m, np.nan, np.nan, n
    se = x.std(ddof=1) / np.sqrt(n)
    h = stats.t.ppf(0.5 + level / 2, n - 1) * se
    return m, m - h, m + h, n


def ratio_ci(log_ratios, level=0.95):
    """Geometric-mean ratio and CI from per-session log ratios."""
    m, lo, hi, n = t_ci(log_ratios, level)
    return np.exp(m), np.exp(lo), np.exp(hi), n


def fmt_ms(x):
    return f"{x:.1f}" if abs(x) >= 1 else f"{x:.2f}"
