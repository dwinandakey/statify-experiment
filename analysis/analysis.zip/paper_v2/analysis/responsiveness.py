"""Responsiveness, start-up responsiveness and overhead decomposition."""
import numpy as np
import pandas as pd

from common import BROWSERS, CELLS, NS, OUT, load_runs, session_medians, t_ci

d = load_runs()
lines = []
p = lines.append

p("\n## Responsiveness during the computation window\n")
d["dropped_any"] = d["droppedFrames"] > 0
d["lt_any"] = d["longTaskCount"] > 0
rows = []
for (b, w, n, c), g in d.groupby(["browser", "workload", "N", "cell"]):
    sm = g.groupby("sessionId")["maxFrameGapMs"].median()
    m, lo, hi, k = t_ci(sm)
    rows.append(dict(browser=b, workload=w, N=n, cell=c,
                     gap_mean=m, gap_lo=lo, gap_hi=hi,
                     gap_p95=g["maxFrameGapMs"].quantile(0.95), gap_max=g["maxFrameGapMs"].max(),
                     dropped_med=g.groupby("sessionId")["droppedFrames"].median().mean(),
                     share_dropped=g["dropped_any"].mean(),
                     share_longtask=g["lt_any"].mean() if g["longTaskCount"].notna().any() else np.nan,
                     lt_total_med=g.groupby("sessionId")["longTaskTotalMs"].median().mean()
                     if g["longTaskTotalMs"].notna().any() else np.nan))
r = pd.DataFrame(rows)
r.to_csv(f"{OUT}/responsiveness.csv", index=False)
for b in BROWSERS:
    for w in ["core", "full"]:
        p(f"\n**{b}/{w}**: median max frame gap (ms, mean of session medians) | share of runs with ≥1 dropped frame | share with long task")
        p("| N | " + " | ".join(CELLS) + " |")
        p("|---|" + "---|" * len(CELLS))
        for n in NS:
            vals = []
            for c in CELLS:
                x = r.query("browser==@b and workload==@w and N==@n and cell==@c").iloc[0]
                lt = "" if np.isnan(x.share_longtask) else f" / LT {x.share_longtask*100:.0f}%"
                vals.append(f"{x.gap_mean:.1f} / {x.share_dropped*100:.0f}%{lt}")
            p(f"| {n:,} | " + " | ".join(vals) + " |")

p("\nWorker cells pooled (all N, both workloads): max-gap p95 and max, share dropped")
for b in BROWSERS:
    for c in ["B-warm", "B-cold", "D-warm", "D-cold"]:
        g = d.query("browser==@b and cell==@c")
        p(f"- {b} {c}: p95 {g['maxFrameGapMs'].quantile(0.95):.1f} ms, max {g['maxFrameGapMs'].max():.1f} ms, "
          f"runs with dropped frames {int(g['dropped_any'].sum())}/{len(g)}, long tasks {int(g['lt_any'].sum()) if g['longTaskCount'].notna().any() else 'n/a'}")
p("\nMain-thread cells: share of runs that were a long task (>50 ms), Chrome")
for w in ["core", "full"]:
    for n in NS:
        parts = []
        for c in ["A", "C"]:
            g = d.query("browser=='chrome' and workload==@w and N==@n and cell==@c")
            parts.append(f"{c} {g['lt_any'].mean()*100:.0f}%")
        p(f"- {w} N={n:,}: " + ", ".join(parts))
p("\nMain-thread cells: median dropped frames (mean of session medians) at N=100,000")
for b in BROWSERS:
    for w in ["core", "full"]:
        parts = [f"{c} {r.query('browser==@b and workload==@w and N==100000 and cell==@c').dropped_med.iloc[0]:.0f}" for c in ["A", "C"]]
        p(f"- {b}/{w}: " + ", ".join(parts))

p("\n## Start-up responsiveness of per-run workers (window from new Worker to ready)\n")
for b in BROWSERS:
    for c in ["B-cold", "D-cold"]:
        g = d.query("browser==@b and cell==@c")
        lt = g["spawnLongTaskCount"]
        p(f"- {b} {c}: spawn max-gap median {g['spawnMaxFrameGapMs'].median():.1f} ms, p95 {g['spawnMaxFrameGapMs'].quantile(0.95):.1f}, max {g['spawnMaxFrameGapMs'].max():.1f}; "
          f"runs with dropped frames {int((g['spawnDroppedFrames']>0).sum())}/{len(g)}; long tasks {int((lt>0).sum()) if lt.notna().any() else 'n/a'}")

p("\n## Overhead decomposition, worker cells (median over runs, mean of session medians, ms)\n")
sm = session_medians(d, ["overheadMs", "dispatchLatencyMs", "returnLatencyMs", "workerHandlerMs", "computeMs"])
sm["handlerExtra"] = sm["workerHandlerMs"] - sm["computeMs"]
for b in BROWSERS:
    for w in ["core", "full"]:
        for c in ["B-warm", "D-warm", "B-cold", "D-cold"]:
            parts = []
            for n in NS:
                g = sm.query("browser==@b and workload==@w and N==@n and cell==@c")
                parts.append(f"{n//1000}k: ovh {g.overheadMs.mean():.2f} = disp {g.dispatchLatencyMs.mean():.2f} + ret {g.returnLatencyMs.mean():.2f} + extra {g.handlerExtra.mean():.2f}")
            p(f"- {b}/{w}/{c}: " + "; ".join(parts))

p("\n## Frame-phase test: does a result wait for a rendering step?\n")
wk = d[d["cell"].isin(["B-warm", "D-warm", "B-cold", "D-cold"])].copy()
# a frame callback ran between the worker's post and the main thread's receipt
wk["frame_between"] = wk["t1PhaseMs"] < wk["returnLatencyMs"]
wk["post_phase"] = (wk["t1PhaseMs"] - wk["returnLatencyMs"]) % 16.667
res = []
for b in BROWSERS:
    g = wk.query("browser==@b")
    a = g[g.frame_between]["returnLatencyMs"]
    nb = g[~g.frame_between]["returnLatencyMs"]
    p(f"- {b}: frame callback between post and receipt in {g.frame_between.mean()*100:.1f}% of worker runs; "
      f"return latency median {a.median():.2f} ms (p90 {a.quantile(.9):.2f}) when a frame intervened vs {nb.median():.2f} ms (p90 {nb.quantile(.9):.2f}) otherwise")
    for c in ["B-warm", "D-warm"]:
        for w in ["core"]:
            for n in NS:
                gg = g.query("cell==@c and workload==@w and N==@n")
                p(f"    · {c}/{w}/N={n//1000}k: frame-between {gg.frame_between.mean()*100:.0f}%, ret median {gg.returnLatencyMs.median():.2f}, "
                  f"overhead median {gg.overheadMs.median():.2f}")
# binned by phase of the post relative to the last frame (only runs without intervening frame are well-defined; use all with modulo)
wk["phase_bin"] = pd.cut(wk["post_phase"], bins=np.arange(0, 17.5, 1.0), include_lowest=True)
ph = wk.groupby(["browser", "phase_bin"], observed=True)["returnLatencyMs"].agg(["median", "count"]).reset_index()
ph.to_csv(f"{OUT}/phase_bins.csv", index=False)
wk[["browser", "workload", "N", "cell", "post_phase", "returnLatencyMs", "dispatchLatencyMs", "overheadMs", "frame_between", "t0PhaseMs"]].to_csv(f"{OUT}/worker_phase_runs.csv", index=False)

open(f"{OUT}/numbers_responsiveness.md", "w").write("# Responsiveness digest\n" + "\n".join(lines) + "\n")
print("\n".join(lines))
