"""LaTeX table bodies (booktabs) for Tables 2 and 3 of the v2 manuscript."""
import numpy as np
import pandas as pd

from common import CELLS, NS, OUT, ROOT

rt = pd.read_csv(f"{OUT}/response_time.csv")
nat = pd.read_csv(f"{OUT}/native.csv")
eff = pd.read_csv(f"{OUT}/effects.csv")
os_tab = f"{ROOT}/tables"
import os

os.makedirs(os_tab, exist_ok=True)


def f1(x):
    return f"{x:.1f}" if x < 100 else f"{x:.0f}"


# ---------------- Table 2: response time
r = rt.query("metric=='responseMs'").copy()
r["half_rel"] = (r["hi"] - r["lo"]) / 2 / r["mean"]
maxhw = r["half_rel"].max() * 100
lines = []
for w, title in [("core", "IRLS core workload"), ("full", "Full analysis workload")]:
    lines.append(r"\midrule" if w == "full" else "")
    lines.append(rf"\multicolumn{{9}}{{@{{}}l}}{{\textit{{{title}}}}}\\")
    for b, bn in [("chrome", "Chrome"), ("firefox", "Firefox")]:
        for i, n in enumerate(NS):
            cells = [f1(r.query("browser==@b and workload==@w and N==@n and cell==@c")["mean"].iloc[0]) for c in CELLS]
            nv = f1(nat.query("N==@n")["mean"].iloc[0]) if w == "core" else "--"
            lab = bn if i == 0 else ""
            lines.append(f"{lab} & {n:,} & " + " & ".join(cells) + f" & {nv} \\\\")
        if b == "chrome":
            lines.append(r"\addlinespace")
body = "\n".join(l for l in lines if l)
open(f"{os_tab}/table2_response_body.tex", "w").write(body + "\n")
print(f"Table 2: max relative 95% CI half-width {maxhw:.1f}%")
w95 = r.sort_values("half_rel", ascending=False).head(3)[["browser", "workload", "N", "cell", "half_rel"]]
print(w95)

# ---------------- Table 3: effects (ratios of response time)
order = [
    ("Technology: Wasm / JS (main thread, C/A)", "Wasm vs JS, main (C/A)"),
    ("Technology: Wasm / JS (persistent worker, D/B)", "Wasm vs JS, worker warm (D-warm/B-warm)"),
    ("Technology: Wasm / JS (per-run worker, D/B)", "Wasm vs JS, worker cold (D-cold/B-cold)"),
    ("Location: worker / main (JS, B-warm/A)", "Worker vs main, JS warm (B-warm/A)"),
    ("Location: worker / main (Wasm, D-warm/C)", "Worker vs main, Wasm warm (D-warm/C)"),
    ("Lifecycle: per-run / persistent (JS)", "Cold vs warm, JS (B-cold/B-warm)"),
    ("Lifecycle: per-run / persistent (Wasm)", "Cold vs warm, Wasm (D-cold/D-warm)"),
]
SEL = [1000, 10000, 100000]
lines = []
for label, key in order:
    lines.append(rf"\multicolumn{{7}}{{@{{}}l}}{{\textit{{{label}}}}}\\")
    for b, bn in [("chrome", "Chrome"), ("firefox", "Firefox")]:
        vals = []
        for w in ["core", "full"]:
            for n in SEL:
                x = eff.query("contrast==@key and metric=='responseMs' and browser==@b and workload==@w and N==@n").iloc[0]
                vals.append(f"{x.ratio:.2f} ({x.lo:.2f}--{x.hi:.2f})")
        lines.append(rf"\quad {bn} & " + " & ".join(vals) + r" \\")
open(f"{os_tab}/table3_effects_body.tex", "w").write("\n".join(lines) + "\n")
print("tables written")
