"""Publication figures for the v2 manuscript (PDF + PNG, 16 cm wide)."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from common import FIG, NS, OUT, load_runs

JS, WASM, NAT, INK, MUTED, GRID = "#eb6834", "#2a78d6", "#52514e", "#0b0b0b", "#8a8984", "#e6e5e1"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 7.5, "axes.titlesize": 8, "axes.labelsize": 7.5,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "axes.edgecolor": MUTED,
    "axes.linewidth": 0.6, "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelcolor": INK,
    "ytick.labelcolor": INK, "axes.labelcolor": INK, "axes.titlecolor": INK, "pdf.fonttype": 42,
    "savefig.dpi": 300, "axes.spines.top": False, "axes.spines.right": False,
})
W = 16 / 2.54
STY = {
    "A": dict(color=JS, ls="-", marker="o", label="A  JS · main thread"),
    "B-warm": dict(color=JS, ls="--", marker="s", label="B-warm  JS · persistent worker"),
    "B-cold": dict(color=JS, ls=":", marker="^", label="B-cold  JS · per-run worker"),
    "C": dict(color=WASM, ls="-", marker="o", label="C  Wasm · main thread"),
    "D-warm": dict(color=WASM, ls="--", marker="s", label="D-warm  Wasm · persistent worker"),
    "D-cold": dict(color=WASM, ls=":", marker="^", label="D-cold  Wasm · per-run worker"),
}
BNAME = {"chrome": "Chrome 155", "firefox": "Firefox 158"}


def save(fig, name):
    fig.savefig(f"{FIG}/{name}.pdf", bbox_inches="tight")
    fig.savefig(f"{FIG}/{name}.png", bbox_inches="tight")
    plt.close(fig)


def style_log_n(ax):
    ax.set_xscale("log")
    ax.set_xticks(NS)
    ax.set_xticklabels(["1k", "10k", "50k", "100k"])
    ax.minorticks_off()
    ax.grid(True, which="major", color=GRID, lw=0.5)
    ax.set_axisbelow(True)


rt = pd.read_csv(f"{OUT}/response_time.csv")
nat = pd.read_csv(f"{OUT}/native.csv")
eff = pd.read_csv(f"{OUT}/effects.csv")
resp = pd.read_csv(f"{OUT}/responsiveness.csv")

# ------------------------------------------------------------------ Figure 1: execution paths
fig, ax = plt.subplots(figsize=(W, 3.1))
ax.set_xlim(0, 100)
ax.set_ylim(-0.5, 34)
ax.axis("off")


def box(x, y, w, h, text, fc, ec=None, tc=INK, fs=5.9, ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.15,rounding_size=0.6",
                                fc=fc, ec=ec or fc, lw=0.8, ls=ls))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=tc)


def arrow(x0, y0, x1, y1):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=6, lw=0.7, color=MUTED))


def span(y, text):
    ax.annotate("", xy=(72.5, y), xytext=(34, y), arrowprops=dict(arrowstyle="<->", lw=0.6, color=INK))
    ax.text(53.25, y - 1.3, text, ha="center", va="center", fontsize=6.1, color=INK)


LIGHT_JS, LIGHT_W, LIGHT_G = "#fbe1d6", "#d8e6f8", "#efeeea"
ax.text(0, 30.0, "Main thread\n(A, C)", ha="left", va="center", fontsize=6.5, color=INK, fontweight="bold")
ax.text(0, 17.2, "Persistent worker\n(B-warm, D-warm)", ha="left", va="center", fontsize=6.5, color=INK, fontweight="bold")
ax.text(0, 4.6, "Per-run worker\n(B-cold, D-cold)", ha="left", va="center", fontsize=6.5, color=INK, fontweight="bold")
# row 1
box(21, 28, 11, 4.2, "data\npreparation", LIGHT_G)
box(34, 28, 38.5, 4.2, "IRLS core or full analysis (JS or Wasm)\nexecuted on the main thread", LIGHT_W, ec=WASM)
box(75, 28, 12, 4.2, "output tables\n(full workload)", LIGHT_G, fs=5.6)
ax.text(88, 30.1, "responseMs", fontsize=6.1, color=INK, va="center")
span(26.4, "computeMs = e2eMs; the page cannot draw frames meanwhile")
# row 2
box(20.5, 18.2, 12, 3.6, "worker created\nonce per batch", "white", ec=MUTED, ls="--", fs=5.5)
box(34, 18.2, 5.5, 3.6, "post\nX, y", LIGHT_G)
box(64.5, 18.2, 7, 3.6, "result\nmessage", LIGHT_G)
box(75, 18.2, 12, 3.6, "output tables\n(full workload)", LIGHT_G, fs=5.6)
ax.text(52, 20.0, "page keeps drawing frames", ha="center", va="center", fontsize=5.7, color=MUTED, style="italic")
box(40.5, 13.6, 23, 3.4, "computation in worker", LIGHT_W, ec=WASM)
arrow(39.5, 18.2, 42.5, 17.0)
arrow(61.5, 17.0, 65, 18.2)
ax.text(88, 20.0, "responseMs", fontsize=6.1, color=INK, va="center")
span(12.2, "e2eMs = dispatch latency + computeMs + return latency")
# row 3
box(21, 5.6, 11, 3.6, "new Worker\n+ init", LIGHT_JS, ec=JS)
box(34, 5.6, 5.5, 3.6, "post\nX, y", LIGHT_G)
box(64.5, 5.6, 7, 3.6, "result,\nterminate", LIGHT_G)
box(75, 5.6, 12, 3.6, "output tables\n(full workload)", LIGHT_G, fs=5.6)
ax.text(52, 7.4, "page keeps drawing frames", ha="center", va="center", fontsize=5.7, color=MUTED, style="italic")
box(40.5, 1.0, 23, 3.4, "computation in a new worker", LIGHT_W, ec=WASM, fs=5.6)
arrow(39.5, 5.6, 42.5, 4.4)
arrow(61.5, 4.4, 65, 5.6)
ax.text(26.5, 0.6, "startupMs\n(spawn + init + engine)", ha="center", va="center", fontsize=5.9, color=JS)
ax.text(88, 7.4, "responseMs\n(incl. startupMs)", fontsize=6.1, color=INK, va="center")
save(fig, "fig1_execution_paths")

# ------------------------------------------------------------------ Figure 2: response time vs N
fig, axes = plt.subplots(2, 2, figsize=(W, 4.6), sharex=True)
for i, w in enumerate(["core", "full"]):
    for j, b in enumerate(["chrome", "firefox"]):
        ax = axes[i, j]
        for c, s in STY.items():
            g = rt.query("browser==@b and workload==@w and cell==@c and metric=='responseMs'").sort_values("N")
            ax.errorbar(g["N"], g["mean"], yerr=[g["mean"] - g["lo"], g["hi"] - g["mean"]], color=s["color"],
                        ls=s["ls"], marker=s["marker"], ms=4, lw=1.3, capsize=0, mec="white", mew=0.6)
        if w == "core":
            ax.plot(nat["N"], nat["mean"], color=NAT, ls="-", marker="D", ms=3.5, lw=1.0, mec="white", mew=0.6)
        ax.set_yscale("log")
        ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}"))
        style_log_n(ax)
        ax.set_title(f"{BNAME[b]} · {'IRLS core' if w == 'core' else 'full analysis'}", loc="left")
        if j == 0:
            ax.set_ylabel("response time (ms)")
        if i == 1:
            ax.set_xlabel("observations N")
_h = {k: Line2D([], [], color=s["color"], ls=s["ls"], marker=s["marker"], ms=4, lw=1.3, mec="white", label=s["label"]) for k, s in STY.items()}
_h["native"] = Line2D([], [], color=NAT, marker="D", ms=3.5, lw=1.0, mec="white", label="native Rust (core, reference)")
handles = [_h[k] for k in ["A", "C", "B-warm", "D-warm", "B-cold", "D-cold", "native"]]
fig.legend(handles=handles, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.07))
fig.tight_layout()
save(fig, "fig2_response_time")

# ------------------------------------------------------------------ Figure 3: lifecycle penalty
fig, axes = plt.subplots(2, 2, figsize=(W, 4.4), sharex=True)
for i, w in enumerate(["core", "full"]):
    for j, metric in enumerate(["computeMs", "responseMs"]):
        ax = axes[i, j]
        ax.axhline(1, color=MUTED, lw=0.7)
        for tech, (cold, warm), col in [("JS", ("B-cold", "B-warm"), JS), ("Wasm", ("D-cold", "D-warm"), WASM)]:
            name = f"Cold vs warm, {tech} ({cold}/{warm})"
            for b, ls, mk in [("chrome", "-", "o"), ("firefox", "--", "s")]:
                g = eff.query("contrast==@name and metric==@metric and browser==@b and workload==@w").sort_values("N")
                ax.errorbar(g["N"], g["ratio"], yerr=[g["ratio"] - g["lo"], g["hi"] - g["ratio"]], color=col, ls=ls,
                            marker=mk, ms=4, lw=1.3, mec="white", mew=0.6, capsize=0)
        ax.set_yscale("log")
        ax.set_yticks([0.8, 1, 1.5, 2, 3, 5, 10, 15])
        ax.set_yticklabels(["0.8", "1", "1.5", "2", "3", "5", "10", "15"])
        ax.minorticks_off()
        style_log_n(ax)
        ax.set_title(("(a) " if (i, j) == (0, 0) else "(b) " if (i, j) == (0, 1) else "(c) " if (i, j) == (1, 0) else "(d) ")
                     + ("computation only" if metric == "computeMs" else "response time incl. start-up")
                     + (" · IRLS core" if w == "core" else " · full analysis"), loc="left")
        if j == 0:
            ax.set_ylabel("per-run / persistent")
        if i == 1:
            ax.set_xlabel("observations N")
handles = [Line2D([], [], color=JS, ls="-", marker="o", ms=4, lw=1.3, mec="white", label="JS · Chrome"),
           Line2D([], [], color=JS, ls="--", marker="s", ms=4, lw=1.3, mec="white", label="JS · Firefox"),
           Line2D([], [], color=WASM, ls="-", marker="o", ms=4, lw=1.3, mec="white", label="Wasm · Chrome"),
           Line2D([], [], color=WASM, ls="--", marker="s", ms=4, lw=1.3, mec="white", label="Wasm · Firefox")]
fig.legend(handles=handles, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.04))
fig.tight_layout()
save(fig, "fig3_lifecycle")

# ------------------------------------------------------------------ Figure 4: responsiveness
d = load_runs()
wk = pd.read_csv(f"{OUT}/worker_phase_runs.csv")
fig = plt.figure(figsize=(W, 2.6))
gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 0.9], wspace=0.42)
for j, b in enumerate(["chrome", "firefox"]):
    ax = fig.add_subplot(gs[0, j])
    ax.axhline(16.7, color=MUTED, lw=0.6, ls="-")
    ax.axhline(50, color=MUTED, lw=0.6, ls="--")
    ax.text(1000, 54, "50 ms (long task)", fontsize=5.8, color=MUTED, va="bottom")
    ax.text(1000, 15.2, "16.7 ms (one frame)", fontsize=5.8, color=MUTED, va="top")
    for c, s in STY.items():
        g = resp.query("browser==@b and workload=='full' and cell==@c").sort_values("N")
        ax.plot(g["N"], g["gap_mean"], color=s["color"], ls=s["ls"], marker=s["marker"], ms=4, lw=1.3, mec="white", mew=0.6)
    ax.set_yscale("log")
    ax.set_yticks([15, 20, 50, 100, 200, 300])
    ax.set_yticklabels(["15", "20", "50", "100", "200", "300"])
    ax.minorticks_off()
    style_log_n(ax)
    ax.set_xticklabels(["1k", "10k", "", "100k"])
    ax.set_ylim(12, 360)
    ax.set_title(f"({'a' if j == 0 else 'b'}) {BNAME[b]}", loc="left")
    ax.set_xlabel("observations N")
    if j == 0:
        ax.set_ylabel("longest frame gap (ms)")
ax = fig.add_subplot(gs[0, 2])
data, labels, cols = [], [], []
for b in ["chrome", "firefox"]:
    g = wk.query("browser==@b")
    for fb, lab in [(False, "no frame"), (True, "frame")]:
        data.append(g[g.frame_between == fb]["returnLatencyMs"].values)
        share = (g.frame_between == fb).mean() * 100
        labels.append(f"{'none' if not fb else 'frame'}\n{share:.0f}%")
        cols.append(WASM if fb else MUTED)
bp = ax.boxplot(data, widths=0.55, showfliers=False, patch_artist=True, medianprops=dict(color=INK, lw=1.0),
                whiskerprops=dict(color=MUTED, lw=0.7), capprops=dict(color=MUTED, lw=0.7))
for patch, c in zip(bp["boxes"], cols):
    patch.set_facecolor(c)
    patch.set_alpha(0.35)
    patch.set_edgecolor(c)
ax.set_xticks(range(1, 5))
ax.set_xticklabels(labels, fontsize=5.8)
ax.text(1.5, -0.21, "Chrome", transform=ax.get_xaxis_transform(), ha="center", fontsize=6.3, color=INK)
ax.text(3.5, -0.21, "Firefox", transform=ax.get_xaxis_transform(), ha="center", fontsize=6.3, color=INK)
ax.set_yscale("log")
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}"))
ax.set_ylabel("return latency (ms)")
ax.set_title("(c) worker → main delay", loc="left")
ax.grid(True, axis="y", color=GRID, lw=0.5)
ax.set_axisbelow(True)
handles = [Line2D([], [], color=s["color"], ls=s["ls"], marker=s["marker"], ms=4, lw=1.3, mec="white", label=k) for k, s in STY.items()]
fig.legend(handles=handles, loc="upper center", ncol=6, frameon=False, bbox_to_anchor=(0.36, 1.08))
save(fig, "fig4_responsiveness")
print("figures written")
