"""Extra numbers: main-thread blocking thresholds, stalls, Firefox JS cold<warm, crossings."""
import numpy as np, pandas as pd
from common import load_runs, OUT
d = load_runs()
L = ["\n## Extra numbers\n"]
m = d[d.cell.isin(["A", "C"])]
for b in ["chrome", "firefox"]:
    for w in ["core", "full"]:
        parts = []
        for n in [1000, 10000, 50000, 100000]:
            g = m.query("browser==@b and workload==@w and N==@n")
            parts.append(f"{n//1000}k: >50ms A {100*(g.query('cell==\"A\"').maxFrameGapMs>50).mean():.0f}% C {100*(g.query('cell==\"C\"').maxFrameGapMs>50).mean():.0f}%; >200ms A {100*(g.query('cell==\"A\"').maxFrameGapMs>200).mean():.0f}% C {100*(g.query('cell==\"C\"').maxFrameGapMs>200).mean():.0f}%")
        L.append(f"- {b}/{w} main-thread frame gap: " + " | ".join(parts))
wk = d[~d.cell.isin(["A", "C"])]
st = wk[wk.maxFrameGapMs > 1000]
L.append(f"\nStalls >1 s in worker runs: {len(st)} of {len(wk)} ({100*len(st)/len(wk):.2f}%); in main-thread runs gap−compute max {(m.maxFrameGapMs-m.computeMs).max():.1f} ms")
L.append(f"Stalled runs e2e range {st.e2eMs.min():.0f}–{st.e2eMs.max():.0f} ms; computeMs normal (median {st.computeMs.median():.0f})")
# worker frame gap overall
L.append(f"Worker runs: median longest frame gap {wk.maxFrameGapMs.median():.1f} ms; share >50 ms {(wk.maxFrameGapMs>50).mean()*100:.2f}%")
# Chrome vs Firefox start-up
open(f"{OUT}/numbers_extra.md", "w").write("\n".join(L) + "\n")
print("\n".join(L))
