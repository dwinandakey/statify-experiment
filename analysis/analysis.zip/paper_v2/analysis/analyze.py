"""Main analysis for the v2 experiment. Writes CSV tables to out/ and a
Markdown digest of every number used in the manuscript to out/numbers.md."""
import numpy as np
import pandas as pd

from common import (BROWSERS, CELLS, NS, OUT, load_native, load_runs, ratio_ci,
                    session_medians, t_ci)

d = load_runs()
nat = load_native()
lines = []


def h(s):
    lines.append("\n## " + s + "\n")


def p(s=""):
    lines.append(s)


METRICS = ["computeMs", "e2eMs", "overheadMs", "responseMs", "startupMs", "wasmCoreMs",
           "formatMs", "totalMs", "spawnMs", "initMs", "engineInitMs", "maxFrameGapMs",
           "droppedFrames", "longTaskCount", "longTaskTotalMs", "wasmMemoryMB",
           "spawnMaxFrameGapMs", "spawnDroppedFrames", "dispatchLatencyMs", "returnLatencyMs",
           "workerHandlerMs", "t0PhaseMs", "t1PhaseMs", "nextFrameAfterT1Ms", "wasmSerializeMs"]
sm = session_medians(d, METRICS)
sm.to_csv(f"{OUT}/session_medians.csv", index=False)

# ---------------------------------------------------------------- overview
h("Overview")
p(f"Recorded runs (measure sessions): {len(d):,}; errors {d['error'].notna().sum()}, "
  f"hidden {int(d['pageHidden'].sum())}, clock-check failures {int(d['clockCheckFailed'].sum())}")
p(f"Sessions per browser: {d.groupby('browser')['sessionId'].nunique().to_dict()}")
p(f"Runs per (browser, workload, N, cell): {d.groupby(['browser','workload','N','cell']).size().unique()}")
it = d.groupby("N")[["iterations", "stepHalvings"]].agg(["min", "max"])
p("Iterations by N: " + "; ".join(f"N={n}: {int(it.loc[n, ('iterations','min')])} it, "
                                 f"{int(it.loc[n, ('stepHalvings','min')])} halving" for n in NS))

# ---------------------------------------------------------------- response time table
h("Response time (mean of session medians, ms, 95% t-CI over 10 sessions)")
rows = []
for (b, w, n, c), g in sm.groupby(["browser", "workload", "N", "cell"]):
    for metric in ["responseMs", "computeMs", "e2eMs"]:
        m, lo, hi, k = t_ci(g[metric])
        rows.append(dict(browser=b, workload=w, N=n, cell=c, metric=metric, mean=m, lo=lo, hi=hi, k=k))
rt = pd.DataFrame(rows)
rt.to_csv(f"{OUT}/response_time.csv", index=False)
for b in BROWSERS:
    for w in ["core", "full"]:
        p(f"\n**{b} / {w}** (responseMs)")
        p("| N | " + " | ".join(CELLS) + " |")
        p("|---|" + "---|" * len(CELLS))
        for n in NS:
            vals = []
            for c in CELLS:
                r = rt.query("browser==@b and workload==@w and N==@n and cell==@c and metric=='responseMs'").iloc[0]
                vals.append(f"{r['mean']:.1f} ({r['lo']:.1f}–{r['hi']:.1f})")
            p(f"| {n:,} | " + " | ".join(vals) + " |")

# ---------------------------------------------------------------- native
h("Native reference (IRLS core, warm)")
nmed = nat.groupby(["invocation", "N"], as_index=False)["computeMs"].median()
nrows = []
for n, g in nmed.groupby("N"):
    m, lo, hi, k = t_ci(g["computeMs"])
    nrows.append(dict(N=n, mean=m, lo=lo, hi=hi, k=k))
nt = pd.DataFrame(nrows)
nt.to_csv(f"{OUT}/native.csv", index=False)
for r in nt.itertuples():
    p(f"N={r.N:,}: native computeMs {r.mean:.2f} ({r.lo:.2f}–{r.hi:.2f}), {r.k} invocations")
# ratios to native (computeMs, and Wasm-internal core time)
p("\nRatio of browser computeMs (mean of session medians) to native mean:")
for b in BROWSERS:
    for n in NS:
        nv = nt.query("N==@n")["mean"].iloc[0]
        parts = []
        for c in ["A", "B-warm", "C", "D-warm"]:
            v = rt.query("browser==@b and workload=='core' and N==@n and cell==@c and metric=='computeMs'")["mean"].iloc[0]
            parts.append(f"{c} {v / nv:.2f}×")
        wc = sm.query("browser==@b and workload=='core' and N==@n and cell=='D-warm'")["wasmCoreMs"].mean()
        parts.append(f"D-warm wasmCore {wc / nv:.2f}×")
        p(f"- {b} N={n:,}: " + ", ".join(parts))
# native accuracy vs browser
cols_b = [c for c in nat.columns if c.startswith("beta_")]
br = d.query("workload=='core' and cell=='D-warm'")
mx = 0.0
for n in NS:
    nb = nat.query("N==@n")[cols_b].iloc[0].values
    bb = br.query("N==@n")[[c.replace("beta_", "B_") for c in cols_b]].values
    mx = max(mx, np.max(np.abs(bb - nb)))
p(f"\nMax |β_native − β_D-warm| over N and sessions: {mx:.2e}")

# ---------------------------------------------------------------- effects
h("Effects as ratios of session medians (geometric mean, 95% CI over sessions)")
piv = sm.pivot_table(index=["browser", "sessionId", "workload", "N"], columns="cell", values="responseMs").reset_index()
pivc = sm.pivot_table(index=["browser", "sessionId", "workload", "N"], columns="cell", values="computeMs").reset_index()
contrasts = {
    "Wasm vs JS, main (C/A)": ("C", "A"),
    "Wasm vs JS, worker warm (D-warm/B-warm)": ("D-warm", "B-warm"),
    "Wasm vs JS, worker cold (D-cold/B-cold)": ("D-cold", "B-cold"),
    "Worker vs main, JS warm (B-warm/A)": ("B-warm", "A"),
    "Worker vs main, Wasm warm (D-warm/C)": ("D-warm", "C"),
    "Cold vs warm, JS (B-cold/B-warm)": ("B-cold", "B-warm"),
    "Cold vs warm, Wasm (D-cold/D-warm)": ("D-cold", "D-warm"),
    "Production D-cold vs A": ("D-cold", "A"),
}
erows = []
for name, (num, den) in contrasts.items():
    for src, tab in [("responseMs", piv), ("computeMs", pivc)]:
        for (b, w, n), g in tab.groupby(["browser", "workload", "N"]):
            lr = np.log(g[num] / g[den])
            r, lo, hi, k = ratio_ci(lr)
            erows.append(dict(contrast=name, metric=src, browser=b, workload=w, N=n, ratio=r, lo=lo, hi=hi, k=k))
eff = pd.DataFrame(erows)
eff.to_csv(f"{OUT}/effects.csv", index=False)
for name in contrasts:
    p(f"\n**{name}** (responseMs; computeMs in brackets)")
    for b in BROWSERS:
        for w in ["core", "full"]:
            parts = []
            for n in NS:
                r = eff.query("contrast==@name and metric=='responseMs' and browser==@b and workload==@w and N==@n").iloc[0]
                rc = eff.query("contrast==@name and metric=='computeMs' and browser==@b and workload==@w and N==@n").iloc[0]
                parts.append(f"{n//1000 if n>=1000 else n}k: {r.ratio:.2f} ({r.lo:.2f}–{r.hi:.2f}) [{rc.ratio:.2f}]")
            p(f"- {b}/{w}: " + "; ".join(parts))

# factorial (warm cells): per session log-effects, t-CI
h("Factorial decomposition on ln(responseMs), warm cells, per session then t-CI")
frows = []
for (b, s, w, n), g in piv.groupby(["browser", "sessionId", "workload", "N"]):
    A, B, C, D = [np.log(g[c].iloc[0]) for c in ["A", "B-warm", "C", "D-warm"]]
    frows.append(dict(browser=b, sessionId=s, workload=w, N=n,
                      tech_main=C - A, loc_js=B - A, interaction=(D - C) - (B - A),
                      tech_avg=((C - A) + (D - B)) / 2, loc_avg=((B - A) + (D - C)) / 2))
fac = pd.DataFrame(frows)
facs = []
for (b, w, n), g in fac.groupby(["browser", "workload", "N"]):
    rec = dict(browser=b, workload=w, N=n)
    for col in ["tech_avg", "loc_avg", "interaction"]:
        m, lo, hi, k = t_ci(g[col])
        rec[col] = (np.exp(m) - 1) * 100
        rec[col + "_lo"] = (np.exp(lo) - 1) * 100
        rec[col + "_hi"] = (np.exp(hi) - 1) * 100
    facs.append(rec)
fac_s = pd.DataFrame(facs)
fac_s.to_csv(f"{OUT}/factorial.csv", index=False)
for r in fac_s.itertuples():
    p(f"- {r.browser}/{r.workload} N={r.N:,}: Wasm {r.tech_avg:+.1f}% ({r.tech_avg_lo:+.1f} to {r.tech_avg_hi:+.1f}), "
      f"worker {r.loc_avg:+.1f}% ({r.loc_avg_lo:+.1f} to {r.loc_avg_hi:+.1f}), "
      f"interaction {r.interaction:+.1f}% ({r.interaction_lo:+.1f} to {r.interaction_hi:+.1f})")

# browser contrast for the same cell (Firefox/Chrome), sessions are independent between browsers
h("Browser contrast Firefox/Chrome, ratio of means of session medians (Welch CI on logs)")
from scipy import stats as st
brows = []
for (w, n, c), g in sm.groupby(["workload", "N", "cell"]):
    a = np.log(g.query("browser=='chrome'")["responseMs"].values)
    f = np.log(g.query("browser=='firefox'")["responseMs"].values)
    diff = f.mean() - a.mean()
    se = np.sqrt(a.var(ddof=1) / len(a) + f.var(ddof=1) / len(f))
    dfw = se**4 / ((a.var(ddof=1) / len(a))**2 / (len(a) - 1) + (f.var(ddof=1) / len(f))**2 / (len(f) - 1))
    q = st.t.ppf(0.975, dfw)
    brows.append(dict(workload=w, N=n, cell=c, ratio=np.exp(diff), lo=np.exp(diff - q * se), hi=np.exp(diff + q * se)))
bc = pd.DataFrame(brows)
bc.to_csv(f"{OUT}/browser_contrast.csv", index=False)
for w in ["core", "full"]:
    for c in CELLS:
        parts = [f"{n//1000}k {bc.query('workload==@w and N==@n and cell==@c').ratio.iloc[0]:.2f}" for n in NS]
        p(f"- {w} {c}: " + ", ".join(parts))

# ---------------------------------------------------------------- cost per row and iteration
h("Marginal cost per row per IRLS iteration (µs), OLS of session-median computeMs on N×iterations")
itn = d.groupby("N")["iterations"].first().to_dict()
srows = []
for (b, s, w, c), g in sm.groupby(["browser", "sessionId", "workload", "cell"]):
    x = np.array([n * itn[n] for n in g["N"]], dtype=float)
    y = g["computeMs"].values
    slope, icpt = np.polyfit(x, y, 1)
    srows.append(dict(browser=b, sessionId=s, workload=w, cell=c, slope_us=slope * 1000, intercept_ms=icpt))
sl = pd.DataFrame(srows)
sls = []
for (b, w, c), g in sl.groupby(["browser", "workload", "cell"]):
    m, lo, hi, k = t_ci(g["slope_us"])
    mi, loi, hii, _ = t_ci(g["intercept_ms"])
    sls.append(dict(browser=b, workload=w, cell=c, slope=m, lo=lo, hi=hi, intercept=mi))
sls = pd.DataFrame(sls)
sls.to_csv(f"{OUT}/slopes.csv", index=False)
for r in sls.itertuples():
    p(f"- {r.browser}/{r.workload}/{r.cell}: {r.slope:.3f} µs ({r.lo:.3f}–{r.hi:.3f}), intercept {r.intercept:.2f} ms")
# native slope
nat_s = []
for inv, g in nmed.groupby("invocation"):
    x = np.array([n * itn[n] for n in g["N"]], dtype=float)
    nat_s.append(np.polyfit(x, g["computeMs"].values, 1)[0] * 1000)
m, lo, hi, k = t_ci(nat_s)
p(f"- native/core: {m:.3f} µs ({lo:.3f}–{hi:.3f})")

# ---------------------------------------------------------------- start-up
h("Start-up of per-run workers (mean of session medians, ms)")
for b in BROWSERS:
    for w in ["core", "full"]:
        for c in ["B-cold", "D-cold"]:
            g = sm.query("browser==@b and workload==@w and cell==@c")
            parts = []
            for col in ["spawnMs", "initMs", "engineInitMs", "startupMs"]:
                parts.append(f"{col} {g[col].mean():.1f}")
            p(f"- {b}/{w}/{c}: " + ", ".join(parts) + f" (range over N of startupMs {g.groupby('N')['startupMs'].mean().min():.1f}–{g.groupby('N')['startupMs'].mean().max():.1f})")

# ---------------------------------------------------------------- drift / battery
h("Drift check: session index (1–10) vs session-median responseMs, per browser/workload/N/cell")
drows = []
for (b, w, n, c), g in sm.groupby(["browser", "workload", "N", "cell"]):
    idx = g["sessionId"].str[-2:].astype(int).values
    y = np.log(g["responseMs"].values)
    rho, pv = st.spearmanr(idx, y)
    early = np.exp(y[idx <= 3].mean() - y[idx > 3].mean())
    drows.append(dict(browser=b, workload=w, N=n, cell=c, rho=rho, p=pv, early_vs_late=early))
dr = pd.DataFrame(drows)
dr.to_csv(f"{OUT}/drift.csv", index=False)
p(f"Spearman rho range {dr.rho.min():.2f} to {dr.rho.max():.2f}; cells with p<0.05: {int((dr.p < 0.05).sum())} of {len(dr)}")
p(f"Ratio sessions 1–3 vs 4–10: median {dr.early_vs_late.median():.3f}, range {dr.early_vs_late.min():.3f}–{dr.early_vs_late.max():.3f}")
cv = sm.groupby(["browser", "workload", "N", "cell"])["responseMs"].agg(lambda x: x.std(ddof=1) / x.mean()).reset_index(name="cv")
cv.to_csv(f"{OUT}/between_session_cv.csv", index=False)
p(f"Between-session CV of session medians: median {cv.cv.median()*100:.1f}%, max {cv.cv.max()*100:.1f}% "
  f"({cv.loc[cv.cv.idxmax(), ['browser','workload','N','cell']].to_dict()})")
within = d.groupby(["browser", "sessionId", "workload", "N", "cell"])["responseMs"].agg(lambda x: x.std(ddof=1) / x.mean()).reset_index(name="cv")
p(f"Within-session CV (30 runs): median {within.cv.median()*100:.1f}%")

# ---------------------------------------------------------------- memory
h("Wasm linear memory (MB), session medians, mean over sessions")
for b in BROWSERS:
    for w in ["core", "full"]:
        parts = []
        for n in NS:
            g = sm.query("browser==@b and workload==@w and N==@n and cell=='D-cold'")
            parts.append(f"{n//1000}k {g['wasmMemoryMB'].mean():.1f}")
        p(f"- {b}/{w} D-cold (per-run peak): " + ", ".join(parts))

# ---------------------------------------------------------------- accuracy
h("Accuracy")
bcols = [c for c in d.columns if c.startswith("B_")]
scols = [c for c in d.columns if c.startswith("SE_")]
for w in ["core", "full"]:
    for n in NS:
        g = d.query("workload==@w and N==@n")
        ref = g.query("cell=='D-warm' and browser=='chrome'").iloc[0]
        db = np.max(np.abs(g[bcols].values - ref[bcols].values.astype(float)))
        ds = np.max(np.abs(g[scols].values - ref[scols].values.astype(float)))
        # bitwise identical within technology and browser?
        same = []
        for b in BROWSERS:
            for tech, cells in [("js", ["A", "B-warm", "B-cold"]), ("wasm", ["C", "D-warm", "D-cold"])]:
                gg = g.query("browser==@b and cell in @cells")[bcols + scols]
                same.append(f"{b}-{tech}:{'bitwise' if (gg.nunique() == 1).all() else 'differs'}")
        cross = []
        for tech, cells in [("js", ["A", "B-warm", "B-cold"]), ("wasm", ["C", "D-warm", "D-cold"])]:
            gg = g.query("cell in @cells")[bcols + scols]
            cross.append(f"{tech} across browsers:{'bitwise' if (gg.nunique() == 1).all() else 'differs'}")
        p(f"- {w} N={n:,}: max|ΔB| {db:.1e}, max|ΔSE| {ds:.1e}; " + ", ".join(same + cross))

open(f"{OUT}/numbers.md", "w").write("# Numbers digest (auto-generated)\n" + "\n".join(lines) + "\n")
print("\n".join(lines))
